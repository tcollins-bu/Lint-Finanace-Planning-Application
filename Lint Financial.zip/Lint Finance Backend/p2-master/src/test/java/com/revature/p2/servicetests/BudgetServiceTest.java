package com.revature.p2.servicetests;

import org.junit.jupiter.api.*;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.revature.p2.model.Budget;
import com.revature.p2.repo.BudgetRepository;
import com.revature.p2.service.BudgetService;
import com.revature.p2.service.BudgetServiceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@DataJpaTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@RunWith(MockitoJUnitRunner.class)
public class BudgetServiceTest {

	@Mock
	private BudgetRepository uRepoMock;

	@InjectMocks
	private BudgetService bserv = new BudgetServiceImpl();
	private AutoCloseable closeable;

	@BeforeEach
	void initService() {
		closeable = MockitoAnnotations.openMocks(this);

	}

	@AfterEach
	void closeService() throws Exception {
		closeable.close();
	}

	@Test
	@Order(1)
	void testFindAll() {

		Budget budget = new Budget("test", 100.00f, new Date(), 0);

		Budget budget1 = new Budget("test1", 101.00f, new Date(), 1);

		List<Budget> budgets = new ArrayList<Budget>();
		budgets.add(budget);
		budgets.add(budget1);

		Mockito.when(uRepoMock.findAll()).thenReturn(budgets);

		List<Budget> result = bserv.findAll();

		Assertions.assertNotEquals(0, result.size());
	}

	@Test
	@Order(2)
	void testFindByBid() {

		Mockito.when(uRepoMock.findByBid(0)).thenReturn(new Budget("test", 100.00f, new Date(), 0));

		Budget result = bserv.findByBid(0);

		Assertions.assertEquals(0, result.getBid());
	}

	@Test
	@Order(3)
	void testSave() {
		Budget budget = new Budget("test", 100.00f, new Date(), 0);

		List<Budget> budgets = new ArrayList<Budget>();
		budgets.add(budget);

		Mockito.when(uRepoMock.findAll()).thenReturn(budgets);

		bserv.save(budget);

		Assertions.assertEquals(budgets, bserv.findAll());
	}

	@Test
	@Order(4)
	void testUpdate() {

		Budget budget = new Budget("test", 100.00f, new Date(), 0);

		List<Budget> budgets = new ArrayList<Budget>();
		budgets.add(budget);

		Mockito.when(uRepoMock.findAll()).thenReturn(budgets);

		budget.setName("testUpdated");

		bserv.update(0, budget);
		bserv.save(budget);

		Assertions.assertEquals("testUpdated", bserv.findAll().get(0).getName());
	}

	@Test
	@Order(5)
	void testDelete() {

		Budget budget = new Budget("test", 100.00f, new Date(), 0);

		Mockito.when(uRepoMock.findById(0)).thenReturn(Optional.of(budget));

		bserv.delete(0);

		Assertions.assertEquals(new ArrayList<Budget>(), bserv.findAll());
	}

	@Test
	@Order(7)
	void testFindByName() {
		Budget budget = new Budget("test1", 101.00f, new Date(), 1);

		List<Budget> budgets = new ArrayList<Budget>();
		budgets.add(budget);

		System.out.println(budgets.toString());

		Mockito.when(uRepoMock.findByName("test")).thenReturn(budgets);

		List<Budget> result = bserv.findByName("test");
		System.out.println(result.toString());

		Assertions.assertEquals(1, result.size());
	}

}
