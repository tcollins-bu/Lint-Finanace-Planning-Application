package com.revature.p2.servicetests;

import org.junit.jupiter.api.*;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.revature.p2.model.Transactions;
import com.revature.p2.repo.TransactionsRepo;
import com.revature.p2.service.TransactionServiceImpl;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@DataJpaTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@RunWith(MockitoJUnitRunner.class)
public class TransactionServiceTest {

	@Mock
	private TransactionsRepo uRepoMock;

	@InjectMocks
	private TransactionServiceImpl tserv = new TransactionServiceImpl();
	private AutoCloseable closeable;

	@BeforeEach
	void initService() {
		closeable = MockitoAnnotations.openMocks(this);

	}

	@AfterEach
	void closeService() throws Exception {
		closeable.close();
	}

	@Test
	@Order(1)
	void testFindAll() {

		Transactions transaction = new Transactions(new Date(), 100.0f, 0);

		Transactions transaction1 = new Transactions(new Date(), 101.00f, 1);

		List<Transactions> transactions = new ArrayList<Transactions>();
		transactions.add(transaction);
		transactions.add(transaction1);

		Mockito.when(uRepoMock.findAll()).thenReturn(transactions);

		List<Transactions> result = tserv.findAll();

		Assertions.assertNotEquals(0, result.size());
	}

	@Test
	@Order(2)
	void testFindByTid() {

		Mockito.when(uRepoMock.findByTid(0))
				.thenReturn(new Transactions(new Date(), 100.0f, 0));

		Transactions result = tserv.findByTid(0);

		Assertions.assertEquals(0, result.getTid());
	}

	@Test
	@Order(3)
	void testSave() {
		Transactions transaction = new Transactions(new Date(), 100.0f, 0);

		List<Transactions> transactions = new ArrayList<Transactions>();
		transactions.add(transaction);

		Mockito.when(uRepoMock.findAll()).thenReturn(transactions);

		tserv.save(transaction);

		Assertions.assertEquals(transactions, tserv.findAll());
	}

	@Test
	@Order(4)
	void testUpdate() {

		Transactions transaction = new Transactions(new Date(), 100.0f, 0);

		List<Transactions> transactions = new ArrayList<Transactions>();
		transactions.add(transaction);

		Mockito.when(uRepoMock.findAll()).thenReturn(transactions);

		transaction.setTransactionAmount(1500.02f);

		tserv.update(0, transaction);
		tserv.save(transaction);

		Assertions.assertEquals(1500.02f, tserv.findAll().get(0).getTransactionAmount());
	}

	@Test
	@Order(5)
	void testDelete() {

		Transactions transaction = new Transactions(new Date(), 100.0f, 0);

		Mockito.when(uRepoMock.findById(0)).thenReturn(Optional.of(transaction));

		tserv.delete(0);

		Assertions.assertEquals(new ArrayList<Transactions>(), tserv.findAll());
	}

	@Test
	@Order(7)
	void testFindByTransactionDate() {
		Transactions transaction = new Transactions(new Date(), 100.0f, 0);

		List<Transactions> transactions = new ArrayList<Transactions>();
		transactions.add(transaction);

		System.out.println(transactions.toString());

		Mockito.when(uRepoMock.findByTransactionDate("test")).thenReturn(transactions);

		List<Transactions> result = tserv.findByTransactionDate("test");
		System.out.println(result.toString());

		Assertions.assertEquals(1, result.size());
	}

}
