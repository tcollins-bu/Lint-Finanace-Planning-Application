package com.revature.p2.servicetests;

import org.junit.jupiter.api.*;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.revature.p2.model.Account;
import com.revature.p2.repo.AccountRepository;
import com.revature.p2.service.AccountService;
import com.revature.p2.service.AccountServiceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@DataJpaTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@RunWith(MockitoJUnitRunner.class)
public class AccountServiceTest {

	@Mock
	private AccountRepository uRepoMock;

	@InjectMocks
	private AccountService accserv = new AccountServiceImpl();
	private AutoCloseable closeable;

	@BeforeEach
	void initService() {
		closeable = MockitoAnnotations.openMocks(this);

	}

	@AfterEach
	void closeService() throws Exception {
		closeable.close();
	}

	@Test
	@Order(1)
	void testFindAll() {

		Account account = new Account("test", 100.00f, 0);

		Account account1 = new Account("test1", 101.00f, 1);

		List<Account> accounts = new ArrayList<Account>();
		accounts.add(account);
		accounts.add(account1);

		Mockito.when(uRepoMock.findAll()).thenReturn(accounts);

		List<Account> result = accserv.findAll();

		Assertions.assertNotEquals(0, result.size());
	}

	@Test
	@Order(2)
	void testFindByAid() {

		Mockito.when(uRepoMock.findByAid(1)).thenReturn(new Account("test1", 101.00f, 1));

		Account result = accserv.findByAid(1);

		Assertions.assertEquals(1, result.getAid());
	}

	@Test
	@Order(3)
	void testSave() {
		Account account = new Account("test", 100.00f, 0);

		List<Account> accounts = new ArrayList<Account>();
		accounts.add(account);

		Mockito.when(uRepoMock.findAll()).thenReturn(accounts);

		accserv.save(account);

		Assertions.assertEquals(accounts, accserv.findAll());
	}

	@Test
	@Order(4)
	void testUpdate() {

		Account account = new Account("test", 100.00f, 0);

		List<Account> accounts = new ArrayList<Account>();
		accounts.add(account);

		Mockito.when(uRepoMock.findAll()).thenReturn(accounts);

		account.setName("testUpdated");

		accserv.update(0, account);
		accserv.save(account);

		Assertions.assertEquals("testUpdated", accserv.findAll().get(0).getName());
	}

	@Test
	@Order(5)
	void testDelete() {

		Account account = new Account("test", 100.00f, 0);

		Mockito.when(uRepoMock.findById(0)).thenReturn(Optional.of(account));

		accserv.delete(0);

		Assertions.assertEquals(new ArrayList<Account>(), accserv.findAll());
	}

	@Test
	@Order(7)
	void testFindByName() {
		Account account = new Account("test", 100.00f, 0);

		List<Account> accounts = new ArrayList<Account>();
		accounts.add(account);

		System.out.println(accounts.toString());

		Mockito.when(uRepoMock.findByName("test")).thenReturn(accounts);

		List<Account> result = accserv.findByName("test");
		System.out.println(result.toString());

		Assertions.assertEquals(1, result.size());
	}

}
