package com.revature.p2.servicetests;

import org.junit.jupiter.api.*;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.revature.p2.model.Bill;
import com.revature.p2.repo.BillRepository;
import com.revature.p2.service.BillService;
import com.revature.p2.service.BillServiceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@DataJpaTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@RunWith(MockitoJUnitRunner.class)
public class BillServiceTest {

	@Mock
	private BillRepository uRepoMock;

	@InjectMocks
	private BillService biserv = new BillServiceImpl();
	private AutoCloseable closeable;

	@BeforeEach
	void initService() {
		closeable = MockitoAnnotations.openMocks(this);

	}

	@AfterEach
	void closeService() throws Exception {
		closeable.close();
	}

	@Test
	@Order(1)
	void testFindAll() {

		Bill bill = new Bill("test", 100.00f, new Date(), 0);

		Bill bill1 = new Bill("test1", 101.00f, new Date(), 1);

		List<Bill> bills = new ArrayList<Bill>();
		bills.add(bill);
		bills.add(bill1);

		Mockito.when(uRepoMock.findAll()).thenReturn(bills);

		List<Bill> result = biserv.findAll();

		Assertions.assertNotEquals(0, result.size());
	}

	@Test
	@Order(2)
	void testFindByBid() {

		Mockito.when(uRepoMock.findByBid(0)).thenReturn(new Bill("test", 100.00f, new Date(), 0));

		Bill result = biserv.findByBid(0);

		Assertions.assertEquals(0, result.getBid());
	}

	@Test
	@Order(3)
	void testSave() {
		Bill bill = new Bill("test", 100.00f, new Date(), 0);

		List<Bill> bills = new ArrayList<Bill>();
		bills.add(bill);

		Mockito.when(uRepoMock.findAll()).thenReturn(bills);

		biserv.save(bill);

		Assertions.assertEquals(bills, biserv.findAll());
	}

	@Test
	@Order(4)
	void testUpdate() {

		Bill bill = new Bill("test", 100.00f, new Date(), 0);

		List<Bill> bills = new ArrayList<Bill>();
		bills.add(bill);

		Mockito.when(uRepoMock.findAll()).thenReturn(bills);

		bill.setName("testUpdated");

		biserv.update(0, bill);
		biserv.save(bill);

		Assertions.assertEquals("testUpdated", biserv.findAll().get(0).getName());
	}

	@Test
	@Order(5)
	void testDelete() {

		Bill bill = new Bill("test", 100.00f, new Date(), 0);

		Mockito.when(uRepoMock.findById(0)).thenReturn(Optional.of(bill));

		biserv.delete(0);

		Assertions.assertEquals(new ArrayList<Bill>(), biserv.findAll());
	}

	@Test
	@Order(7)
	void testFindByName() {
		Bill bill = new Bill("test1", 101.00f, new Date(), 1);

		List<Bill> bills = new ArrayList<Bill>();
		bills.add(bill);

		System.out.println(bills.toString());

		Mockito.when(uRepoMock.findByName("test")).thenReturn(bills);

		List<Bill> result = biserv.findByName("test");
		System.out.println(result.toString());

		Assertions.assertEquals(1, result.size());
	}

}
