package com.revature.p2.servicetests;

import org.junit.jupiter.api.*;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.revature.p2.model.Account;
import com.revature.p2.model.Bill;
import com.revature.p2.model.Budget;
import com.revature.p2.model.Transactions;
import com.revature.p2.model.User;
import com.revature.p2.repo.UserRepository;
import com.revature.p2.service.UserService;
import com.revature.p2.service.UserServiceImpl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;

@DataJpaTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@RunWith(MockitoJUnitRunner.class)
public class UserServiceTest {

	@Mock
	private UserRepository uRepoMock;

	@InjectMocks
	private UserService userv = new UserServiceImpl();
	private AutoCloseable closeable;

	@BeforeEach
	void initService() {
		closeable = MockitoAnnotations.openMocks(this);

	}

	@AfterEach
	void closeService() throws Exception {
		closeable.close();
	}

	@Test
	@Order(1)
	void testFindAll() {

		User user = new User(0, "test", "test@test", "testUser", "testPass", new HashSet<Bill>(),
				new HashSet<Account>(), new HashSet<Budget>(), new HashSet<Transactions>());

		User user1 = new User(1, "test1", "test1@test", "test1User", "test1Pass", new HashSet<Bill>(),
				new HashSet<Account>(), new HashSet<Budget>(), new HashSet<Transactions>());

		List<User> users = new ArrayList<User>();
		users.add(user);
		users.add(user1);

		Mockito.when(uRepoMock.findAll()).thenReturn(users);

		List<User> result = userv.findAll();

		Assertions.assertNotEquals(0, result.size());
	}

	@Test
	@Order(2)
	void testFindById() {

		Mockito.when(uRepoMock.findById(1)).thenReturn(
				Optional.of(new User(1, "test1", "test1@test", "test1User", "test1Pass", new HashSet<Bill>(),
						new HashSet<Account>(), new HashSet<Budget>(), new HashSet<Transactions>())));

		User result = userv.findById(1);

		Assertions.assertEquals(1, result.getId());
	}

	@Test
	@Order(3)
	void testSave() {
		User user = new User(0, "test", "test@test", "testUser", "testPass", new HashSet<Bill>(),
				new HashSet<Account>(), new HashSet<Budget>(), new HashSet<Transactions>());

		List<User> users = new ArrayList<User>();
		users.add(user);

		Mockito.when(uRepoMock.findAll()).thenReturn(users);

		userv.save(user);

		Assertions.assertEquals(users, userv.findAll());
	}

	@Test
	@Order(4)
	void testUpdate() {

		User user = new User(0, "test", "test@test", "testUser", "testPass", new HashSet<Bill>(),
				new HashSet<Account>(), new HashSet<Budget>(), new HashSet<Transactions>());

		List<User> users = new ArrayList<User>();
		users.add(user);

		Mockito.when(uRepoMock.findAll()).thenReturn(users);

		user.setName("testUpdated");

		userv.update(0, user);
		userv.save(user);

		Assertions.assertEquals("testUpdated", userv.findAll().get(0).getName());
	}

	@Test
	@Order(5)
	void testDelete() {

		User user = new User(0, "test", "test@test", "testUser", "testPass", new HashSet<Bill>(),
				new HashSet<Account>(), new HashSet<Budget>(), new HashSet<Transactions>());

		Mockito.when(uRepoMock.findById(0)).thenReturn(Optional.of(user));

		userv.delete(0);

		Assertions.assertEquals(new ArrayList<User>(), userv.findAll());
	}

	@Test
	@Order(6)
	void testFindByEmail() {

		User user = new User(1, "test1", "test1@test", "test1User", "test1Pass", new HashSet<Bill>(),
				new HashSet<Account>(), new HashSet<Budget>(), new HashSet<Transactions>());

		List<User> users = new ArrayList<User>();
		users.add(user);

		System.out.println(users.toString());

		Mockito.when(uRepoMock.findByEmail("test1@test")).thenReturn(users);

		List<User> result = userv.findByEmail("test1@test");
		System.out.println(result.toString());

		Assertions.assertEquals(1, result.size());

	}

	@Test
	@Order(7)
	void testFindByUsername() {
		User user = new User(1, "test1", "test1@test", "test1User", "test1Pass", new HashSet<Bill>(),
				new HashSet<Account>(), new HashSet<Budget>(), new HashSet<Transactions>());

		List<User> users = new ArrayList<User>();
		users.add(user);

		System.out.println(users.toString());

		Mockito.when(uRepoMock.findByUsername("test1User")).thenReturn(users);

		List<User> result = userv.findByUsername("test1User");
		System.out.println(result.toString());

		Assertions.assertEquals(1, result.size());
	}

}
