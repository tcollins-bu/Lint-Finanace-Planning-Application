export interface Transactions {
  transactionDate: Date;
  transactionAmount: number;
  tid: number;
}
