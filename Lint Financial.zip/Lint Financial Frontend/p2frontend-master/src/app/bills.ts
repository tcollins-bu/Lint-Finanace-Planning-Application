export interface Bills {
  id: number;
  name: string;
  amount: number;
  bid: number;
  dueDate: Date;
}
