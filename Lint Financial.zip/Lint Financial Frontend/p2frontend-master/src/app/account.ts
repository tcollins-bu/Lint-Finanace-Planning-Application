export interface Account {
  name: string;
  balance: number;
  aid: number;
}
